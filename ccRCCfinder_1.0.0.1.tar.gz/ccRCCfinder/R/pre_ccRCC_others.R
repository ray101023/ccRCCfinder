#' Prediction of ccRCC tumors and other urinary related samples
#'
#'
#' @param data M vlue test dataset; must have column names and row names: row names with CpG sites and column names with sample names
#' @param parallel Number of parallels; The higher the parallel number, the faster the speed, based on the capacity of the computer, it is recommended to use less than 10 to prevent errors
#'
#' @return Factor of prediction from test data
#' @export
#'
#' @examples pre_test <- pre_ccRCC_others(test_data,parallel = 4)

pre_ccRCC_others <- function(data,parallel=4){
  data("train_ccRCC_others")
  library(caret)
  library(caretEnsemble)
  library(doParallel)
  registerDoParallel(parallel)
  getDoParWorkers()
  set.seed(123)
  train_group <- c(rep("ccRCC",323),rep("others",1471))
  my_control <- trainControl(method = "repeatedcv",             # for ???cross-validation???
                             number = 10,                # number of k-folds
                             repeats=3,
                             savePredictions = "final", # cbind
                             index = createResample(as.factor(train_group), 10),
                             #search = "random",
                             classProbs=TRUE,
                             allowParallel = TRUE)

  marker_selection <- c("cg19364784",
                        "cg13475333",
                        "cg10290276",
                        "cg26549084",
                        "cg18428234",
                        "cg19890739",
                        "cg09442654",
                        "cg22239727",
                        "cg00031162",
                        "cg08662052",
                        "cg20285026",
                        "cg20996561",
                        "cg09257635"
  )

  train_data <- train_ccRCC_others[marker_selection,]
  #train_group <- c(rep("N",160),rep("MT",60),rep("LT",106))
  set.seed(917)
  model_list <- caretList(x=t(as.matrix(train_data)),
                          y=as.factor(train_group),
                          trControl = my_control,
                          metric="Accuracy",
                          methodList = c("knn","rpart","lda"),  #lm
                          #               "xgbTree"),
                          tuneList=list(
                            rf=caretModelSpec(method="rf", tuneGrid=data.frame(.mtry=c(1:10))),
                            gbm=caretModelSpec(method="gbm", tuneGrid=data.frame(.interaction.depth = (1:5) * 2,
                                                                                 .n.trees = (1:10)*25,
                                                                                 .shrinkage = seq(.0005, .05,.0005),
                                                                                 .n.minobsinnode=c(5,10,15,20))),
                            svmRadial=caretModelSpec(method="svmRadial", tuneGrid=data.frame(.sigma = 10^(-1:4),
                                                                                             .C = 10^(0:5))),
                            nnet=caretModelSpec(method="nnet", tuneLength=2, trace=FALSE)),
                          continue_on_fail = FALSE)


  stackControl <- trainControl(method = "repeatedcv",number = 10,repeats = 3,savePredictions = TRUE,classProbs = TRUE)

  set.seed(917)
  stack.gbm <- caretStack(model_list, method='gbm',
                          metric="Accuracy",
                          trControl=stackControl)

  predict_test_data <- predict(stack.gbm,newdata=t(as.matrix(data[marker_selection,])),type="raw")
  return(predict_test_data)
}
