#' M  value of ccRCC train dataset (N,LT and MT)
#'
#' A dataset containing the M values of almost 236 ccRCC-special
#'  markers among N, LT and MT stages. The variables are as follows:
#'
#' \itemize{
#'   \item sample_1. M values
#'   \item sample_2. M values
#'   \item sample_3. M values
#'   \item sample_4. M values
#'   \item sample_5. M values
#'   \item sample_6. M values
#'   \item sample_7. M values
#'   \item sample_8. M values
#'   \item ......
#'   \item sample_326. M values
#' }
#'
#' @docType data
#' @keywords datasets
#' @name train_ccRCC_stage
#' @usage data(train_ccRCC_stage)
#' @format A data frame with 236 rows and 326 variables
"train_ccRCC_stage"

#' M  value of ccRCC train dataset (ccRCC and others)
#'
#' A dataset containing the M values of almost 57 ccRCC-special
#'  markers between ccRCC tumors and other urinary system related samples. The variables are as follows:
#'
#' \itemize{
#'   \item sample_1. M values
#'   \item sample_2. M values
#'   \item sample_3. M values
#'   \item sample_4. M values
#'   \item sample_5. M values
#'   \item sample_6. M values
#'   \item sample_7. M values
#'   \item sample_8. M values
#'   \item ......
#'   \item sample_57. M values
#' }
#'
#' @docType data
#' @keywords datasets
#' @name train_ccRCC_others
#' @usage data(train_ccRCC_others)
#' @format A data frame with 57 rows and 1794 variables
"train_ccRCC_others"
