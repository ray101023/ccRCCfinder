#' Prediction of different states of ccRCC and normal kidney tissue
#'
#'
#' @param data M vlue test dataset; must have column names and row names: row names with CpG sites and column names with sample names
#' @param parallel Number of parallels; The higher the parallel number, the faster the speed, based on the capacity of the computer, it is recommended to use less than 10 to prevent errors
#'
#' @return Factor of prediction from test data
#' @export
#'
#' @examples pre_test <- pre_ccRCC_stage(test_data,parallel = 4)

pre_ccRCC_stage <- function(data,parallel=4){
  data("train_ccRCC_stage")
  library(caret)
  library(caretEnsemble)
  library(doParallel)
  registerDoParallel(parallel)
  getDoParWorkers()
  set.seed(123)
  train_group <- c(rep("N",160),rep("MT",60),rep("LT",106))
  my_control <- trainControl(method = "repeatedcv",             # for ???cross-validation???
                             number = 10,                # number of k-folds
                             repeats=3,
                             savePredictions = "final", # cbind
                             index = createResample(as.factor(train_group), 10),
                             #search = "random",
                             classProbs=TRUE,
                             allowParallel = TRUE)

  marker_selection <- c("cg10290276","cg08662052","cg20801476","cg01097384","cg00891541","cg19364784","cg16836311",
  "cg17105755","cg05732750","cg05222982","cg08602008","cg19890739","cg01345315","cg24720008","cg08782899","cg13319711",
  "cg21002957","cg19165946","cg20192747","cg09257635","cg26333652","cg17128947","cg01206211","cg10556064","cg24152605",
  "cg06529756","cg18428234","cg07195011","cg15959205","cg07565505","cg00510870","cg14451382","cg16486109","cg22239727",
  "cg26549084","cg07247419","cg19915582","cg26115633","cg09442654","cg04051152","cg08981980","cg20079298","cg12187394",
  "cg27549720","cg03125498","cg06516502","cg15990629","cg02018681","cg13475333","cg27629992","cg17665699","cg03318573",
  "cg13954457","cg20996561","cg01348293","cg27663389","cg16247183","cg04066265","cg15676707","cg25968569","cg16834823",
  "cg20285026","cg15439862","cg00031162","cg21503392")

  train_data <- train_ccRCC_stage[marker_selection,]
  #train_group <- c(rep("N",160),rep("MT",60),rep("LT",106))
  set.seed(917)
  model_list <- caretList(x=t(as.matrix(train_data)),
                          y=as.factor(train_group),
                          trControl = my_control,
                          metric="Accuracy",
                          methodList = c("knn","rpart","lda"),  #lm
                          #               "xgbTree"),
                          tuneList=list(
                          rf=caretModelSpec(method="rf", tuneGrid=data.frame(.mtry=c(1:10))),
                          gbm=caretModelSpec(method="gbm", tuneGrid=data.frame(.interaction.depth = (1:5) * 2,
                                                                                 .n.trees = (1:10)*25,
                                                                                 .shrinkage = seq(.0005, .05,.0005),
                                                                                 .n.minobsinnode=c(5,10,15,20))),
                          svmRadial=caretModelSpec(method="svmRadial", tuneGrid=data.frame(.sigma = 10^(-1:4),
                                                                                             .C = 10^(0:5))),
                          nnet=caretModelSpec(method="nnet", tuneLength=2, trace=FALSE)),
                          continue_on_fail = FALSE)


  stackControl <- trainControl(method = "repeatedcv",number = 10,repeats = 3,savePredictions = TRUE,classProbs = TRUE)

  set.seed(917)
  stack.gbm <- caretStack(model_list, method='gbm',
                          metric="Accuracy",
                          trControl=stackControl)

  predict_test_data <- predict(stack.gbm,newdata=t(as.matrix(data[marker_selection,])),type="raw")
  return(predict_test_data)
}
