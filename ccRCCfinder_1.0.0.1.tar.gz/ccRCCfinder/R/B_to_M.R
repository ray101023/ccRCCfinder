#' The conversion of B values to M values
#'
#'
#' @param data B vlue dataset; must have column names and row names: row names with CpG sites and column names with sample names
#'
#' @return matrix of dataset
#' @export
#'
#' @examples M <- B_to_M(B)

B_to_M <- function(B){
  log2((B+0.0001)/(1-B+0.0001))
}
